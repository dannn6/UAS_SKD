
path = input(r"file : ")
kunci = int(input("Kunci Enkripsi/Dekripsi: "))
print()
print(f"file : {path}")
print(f"Kunci Enkripsi/Dekripsi : {kunci}\n")

file = open(path, 'rb')
data = file.read()
file.close()

data = bytearray(data)
for index, nilai in enumerate(data):
        data[index] = nilai ^ kunci

file = open(path,'wb')
file.write(data)
file.close()
print("Enkripsi/Dekripsi File Selesai")    

